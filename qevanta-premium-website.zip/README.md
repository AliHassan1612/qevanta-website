Upload index.html and style.css to your GitHub Pages repo.
