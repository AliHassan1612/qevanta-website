Qevanta Website Final With Policies

Upload only:
- index.html
- style.css

Do NOT upload this ZIP as the website source. GitHub Pages reads index.html directly.
