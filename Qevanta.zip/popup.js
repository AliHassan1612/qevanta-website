"use strict";

const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";
const QEVANTA_WEBSITE_URL = "https://alihassan1612.github.io/qevanta-website/#pricing";

const $ = id => document.getElementById(id);
const els = {
  setup:$("setup"), bulk:$("bulk"), progress:$("progress"), results:$("results"), links:$("links"), openlinks:$("openlinks"), guide:$("guide"), privacy:$("privacy"), account:$("account"),
  urls:$("urls"), trades:$("trades"), includeWords:$("includeWords"), excludeWords:$("excludeWords"),
  countryFilter:$("countryFilter"), stateFilter:$("stateFilter"), cityFilter:$("cityFilter"), requireLocation:$("requireLocation"),
  minScore:$("minScore"), delay:$("delay"), noNewLimit:$("noNewLimit"), alert:$("alert"),
  phase:$("phase"), detail:$("detail"), bar:$("bar"), sourcesDone:$("sourcesDone"),
  collected:$("collected"), scanned:$("scanned"), matched:$("matched"), logs:$("logs"),
  resultCount:$("resultCount"), filter:$("filter"), tradeFilter:$("tradeFilter"),
  tradeChips:$("tradeChips"), tables:$("tables"), bulkUrls:$("bulkUrls"), bulkLocked:$("bulkLocked"), bulkContent:$("bulkContent"), savedLists:$("savedLists"),
  listName:$("listName"), summaryCards:$("summaryCards"), extractedLinks:$("extractedLinks"), openLinksBox:$("openLinksBox"), linksCount:$("linksCount"), openLinksLimitText:$("openLinksLimitText"), openLinksStatus:$("openLinksStatus")
};

const PLAN_CONFIG = {
  TRIAL: {name:"TRIAL", credits:50, scanLimit:50, visibleLeads:5, bulk:false, openLimit:0, minDelay:1200, label:"Trial"},
  FREE: {name:"FREE", credits:100, scanLimit:100, visibleLeads:10, bulk:false, openLimit:5, minDelay:900, label:"Free"},
  STARTER: {name:"STARTER", credits:3000, scanLimit:3000, visibleLeads:999999, bulk:true, openLimit:10, minDelay:500, label:"Starter"},
  PRO: {name:"PRO", credits:10000, scanLimit:10000, visibleLeads:999999, bulk:true, openLimit:25, minDelay:300, label:"Pro"},
  AGENCY: {name:"AGENCY", credits:"Unlimited", scanLimit:999999, visibleLeads:999999, bulk:true, openLimit:50, minDelay:100, label:"Agency"}
};

let leads = [], logs = [], running = false, paused = false, currentView = "setup";

bootQevantaAuth();

(function qevantaIntegrityLayer(){
  // Client-side integrity layer for Qevanta extension runtime.
  try {
    Object.defineProperty(window, "__QEVANTA_BUILD", {value:"6.8.0", writable:false, configurable:false});
  } catch(e) {}
})();

async function init(){
  const data = await chrome.storage.local.get([
    "form","leads","logs","running","bulkUrls","savedLists","theme","mockUser","deviceId","plan","extractedLinks","openLinks"
  ]);

  if (!data.deviceId) {
    data.deviceId = generateDeviceId();
    await chrome.storage.local.set({deviceId:data.deviceId});
  }

  if (data.form) setForm(data.form);
  els.bulkUrls.value = (data.bulkUrls || []).join("\n");
  if (els.extractedLinks) els.extractedLinks.value = (data.extractedLinks || []).join("\n");
  if (els.openLinksBox) els.openLinksBox.value = (data.openLinks || []).join("\n");
  leads = data.leads || [];
  logs = data.logs || [];
  running = !!data.running;

  applyTheme(data.theme || "dark");
  updateAccountUI(data.mockUser || null, data.plan || {name:"FREE", credits:100}, data.deviceId);

  chrome.runtime.onMessage.addListener(onMsg);
  bind();

  renderLogs();
  renderResults();
  renderSavedLists(data.savedLists || []);
  updateDashboard();
  show(running ? "progress" : "setup");
}

function bind(){
  document.querySelectorAll(".nav").forEach(btn => btn.onclick = () => show(btn.dataset.view));
  $("btnResults").onclick = () => { show("results"); renderResults(); };
  $("btnBack").onclick = () => show("setup");

  $("btnSave").onclick = saveForm;
  if ($("btnReset")) $("btnReset").onclick = resetAnalysis;
  $("btnStart").onclick = start;
  $("btnPause").onclick = () => chrome.runtime.sendMessage({type: paused ? "RESUME" : "PAUSE"});
  $("btnStop").onclick = () => chrome.runtime.sendMessage({type:"STOP"});
  $("btnClear").onclick = clearResults;
  $("btnCSV").onclick = () => {
    const p = currentPlanConfig().name;
    if (p === "TRIAL" || p === "FREE") return showPaidFeature("CSV Export is available on Starter, Pro, and Agency plans.");
    exportCSV();
  };
  $("btnExcel").onclick = () => {
    const p = currentPlanConfig().name;
    if (p === "TRIAL" || p === "FREE" || p === "STARTER") return showPaidFeature("Excel Export is available on Pro and Agency plans.");
    exportExcel();
  };
  $("btnCopy").onclick = copyURLs;
  $("btnExtractLinks").onclick = extractLeadLinks;
  $("btnLinksCSV").onclick = exportLinksCSV;
  $("btnCopyLinks").onclick = copyExtractedLinks;
  $("btnSendToOpener").onclick = sendLinksToOpener;
  $("btnGoOpenLinks").onclick = () => show("openlinks");
  $("btnOpenBatch").onclick = openLinksBatch;
  $("btnCleanOpenLinks").onclick = cleanOpenLinks;
  $("btnClearOpenLinks").onclick = async () => { els.openLinksBox.value = ""; await chrome.storage.local.set({openLinks:[]}); updateOpenLimitUI(); };
  $("btnMoveResults").onclick = () => { closeStopModal(); show("results"); renderResults(); };
  $("btnStayProgress").onclick = closeStopModal;

  $("btnTheme").onclick = toggleTheme;
  if ($("btnCloseUpgrade")) $("btnCloseUpgrade").onclick = closeUpgradeModal;
  if ($("btnUpgradeModal")) $("btnUpgradeModal").onclick = () => { closeUpgradeModal(); show("account"); };
  if ($("openBatch")) $("openBatch").addEventListener("input", enforceOpenBatchLimit);
  if ($("openDelay")) $("openDelay").addEventListener("input", enforceDelayLimit);
  if ($("delay")) $("delay").addEventListener("input", enforceDelayLimit);
  $("btnUpgrade").onclick = () => chrome.tabs.create({url: QEVANTA_WEBSITE_URL});
  if ($("btnBulkUpgrade")) $("btnBulkUpgrade").onclick = () => chrome.tabs.create({url: QEVANTA_WEBSITE_URL});
  document.querySelectorAll("[data-plan]").forEach(btn => btn.onclick = () => chrome.tabs.create({url: QEVANTA_WEBSITE_URL}));

  $("btnLoadBulk").onclick = () => {
    if (!currentPlanConfig().bulk) return showPaidFeature("Bulk URL Manager is available on any paid plan.");
    const linesToAdd = lines(els.bulkUrls.value);
    if (linesToAdd.length) els.urls.value = linesToAdd.join("\n");
    show("bulk");
  };
  $("btnImportBulk").onclick = importBulkToAnalysis;
  $("btnCleanBulk").onclick = cleanBulkUrls;
  $("btnOpenAll").onclick = openAllBulkTabs;
  $("btnClearBulk").onclick = async () => { els.bulkUrls.value = ""; await chrome.storage.local.set({bulkUrls:[]}); };
  $("btnSaveList").onclick = saveCurrentList;

  if ($("btnUpgradeAccount")) $("btnUpgradeAccount").onclick = () => chrome.tabs.create({url: QEVANTA_WEBSITE_URL});
  if ($("logoutBtn")) $("logoutBtn").onclick = qevantaLogout;

  els.filter.oninput = renderResults;
  els.tradeFilter.onchange = renderResults;

  ["urls","trades","includeWords","excludeWords","minScore","delay","noNewLimit"].forEach(id=>{
    $(id).addEventListener("input", debounce(saveForm, 400));
  });
  els.urls.addEventListener("input", enforceSourceUrlLimit);
  els.urls.addEventListener("paste", () => setTimeout(enforceSourceUrlLimit, 0));
  els.bulkUrls.addEventListener("input", debounce(()=> chrome.storage.local.set({bulkUrls: lines(els.bulkUrls.value)}), 400));
  els.extractedLinks.addEventListener("input", debounce(()=> chrome.storage.local.set({extractedLinks: lines(els.extractedLinks.value)}), 300));
  els.openLinksBox.addEventListener("input", debounce(()=> chrome.storage.local.set({openLinks: lines(els.openLinksBox.value)}), 300));
  document.querySelectorAll("input[name=listType]").forEach(r=>r.addEventListener("change",saveForm));
}

function onMsg(msg){
  if (msg.type === "PROGRESS") {
    running = true;
    show("progress");
    els.phase.textContent = msg.phase || "";
    els.detail.textContent = msg.detail || "";
    els.sourcesDone.textContent = msg.sourcesDone ?? 0;
    els.collected.textContent = msg.collected ?? 0;
    els.scanned.textContent = msg.scanned ?? 0;
    els.matched.textContent = msg.matched ?? 0;
    els.bar.style.width = (msg.percent || 0) + "%";
    updateDashboard({collected:msg.collected, scanned:msg.scanned, matched:msg.matched});
  }

  if (msg.type === "LOG") {
    logs.push(msg.text);
    if (logs.length > 300) logs.shift();
    chrome.storage.local.set({logs});
    renderLogs();
  }

  if (msg.type === "LEAD") {
    leads.push(msg.lead);
    chrome.storage.local.set({leads});
    renderResults();
    updateDashboard();
  }

  if (msg.type === "DONE") {
    running = false; paused = false;
    if (Array.isArray(msg.leads)) leads = mergeLeads(leads, msg.leads);
    chrome.storage.local.set({running:false, leads});
    show("results");
    renderResults();
    updateDashboard();
  }

  if (msg.type === "STOPPED") {
    running = false; paused = false;
    if (Array.isArray(msg.leads)) leads = mergeLeads(leads, msg.leads);
    chrome.storage.local.set({running:false, leads});
    renderResults();
    updateDashboard({collected:msg.collected, scanned:msg.scanned, matched:leads.length});
    showStopModal(msg);
  }

  if (msg.type === "ERROR") {
    running = false;
    chrome.storage.local.set({running:false});
    showAlert(msg.message || "Something went wrong.");
    show("setup");
  }

  if (msg.type === "PAUSED") { paused = true; $("btnPause").textContent = "Resume"; }
  if (msg.type === "RESUMED") { paused = false; $("btnPause").textContent = "Pause"; }
}

async function start(){
  hideAlert();
  if(!canScanMore()){
    showPaidFeature("Monthly profile limit reached. Upgrade your plan to continue scanning.");
    return;
  }
  await saveForm();

  enforceSourceUrlLimit();
  const form = getForm();
  if (!form.urls.length) return showAlert("Please add at least one Instagram profile URL.");
  if (!form.trades.length) return showAlert("Please add at least one target lead type.");

  leads = [];
  logs = [];
  renderLogs();
  renderResults();

  await chrome.storage.local.set({leads, logs, running:true});
  show("progress");

  chrome.runtime.sendMessage({type:"START", ...form, plan: currentPlanConfig().name, maxProfiles: currentPlanConfig().scanLimit}, () => {
    if (chrome.runtime.lastError) showAlert(chrome.runtime.lastError.message);
  });
}

function getForm(){
  return {
    urls: allowedSourceUrls(),
    trades: lines(els.trades.value),
    includeWords: lines(els.includeWords.value),
    excludeWords: lines(els.excludeWords.value),
    location: ["TRIAL","FREE","STARTER"].includes(currentPlanConfig().name) ? {country:"", state:"", city:"", require:false} : {
      country: els.countryFilter?.value?.trim() || "",
      state: els.stateFilter?.value?.trim() || "",
      city: els.cityFilter?.value?.trim() || "",
      require: !!els.requireLocation?.checked
    },
    listType: document.querySelector("input[name=listType]:checked").value,
    minScore: +els.minScore.value || 35,
    delay: Math.max(currentPlanConfig().minDelay, +els.delay.value || currentPlanConfig().minDelay),
    noNewLimit: +els.noNewLimit.value || 25,
    maxProfiles: currentPlanConfig().scanLimit
  };
}

function setForm(f){
  els.urls.value = (f.urls || []).join("\n");
  els.trades.value = (f.trades || []).join("\n");
  els.includeWords.value = (f.includeWords || []).join("\n");
  els.excludeWords.value = (f.excludeWords || []).join("\n");
  if (els.countryFilter) els.countryFilter.value = f.location?.country || "";
  if (els.stateFilter) els.stateFilter.value = f.location?.state || "";
  if (els.cityFilter) els.cityFilter.value = f.location?.city || "";
  if (els.requireLocation) els.requireLocation.checked = !!f.location?.require;
  els.minScore.value = f.minScore ?? 35;
  els.delay.value = f.delay ?? 900;
  els.noNewLimit.value = f.noNewLimit ?? 25;
  if (f.listType) document.querySelector(`input[name=listType][value="${f.listType}"]`).checked = true;
}

async function saveForm(){
  await chrome.storage.local.set({form:getForm()});
}

function show(name){
  currentView = name;
  ["setup","bulk","progress","results","links","openlinks","guide","privacy","account"].forEach(n=>els[n].classList.toggle("hidden", n !== name));
  document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active", b.dataset.view === name));
  const titles = {
    setup:["New Analysis","Turn any Instagram audience into targeted opportunities."],
    bulk:["Bulk URL Manager","Open, save, and reuse multiple Instagram source profiles."],
    progress:["Live Scan","Track audience collection, scoring, and matching in real time."],
    results:["Results","Review, filter, and export your targeted leads."],
    links:["Extracted Links","Copy, export, or move matched profile links to the opener."],
    openlinks:["Open Links","Open lead links in controlled batches based on your plan."],
    guide:["Safe Use Guide","Avoid unnecessary risk while using Instagram automation."],
    privacy:["Privacy","Local storage now. Backend policy and license verification before paid launch."],
    account:["Pricing & Account","Manage your plan, license, device status, and upgrade access."]
  };
  $("pageTitle").textContent = titles[name][0];
  $("pageSubtitle").textContent = titles[name][1];
  updatePlanLocks();
}

function lines(s){
  return String(s || "").split(/\n+/).map(x=>x.trim()).filter(Boolean);
}

function normalizeInstagramUrl(value){
  const v = String(value || "").trim();
  if (!v) return "";
  if (v.includes("instagram.com")) return v.split("?")[0].replace(/\/?$/, "/");
  const username = v.replace(/^@/,"").replace(/[^\w.]/g,"");
  return username ? `https://www.instagram.com/${username}/` : "";
}

function allowedSourceUrls(){
  const clean = lines(els.urls.value).map(normalizeInstagramUrl).filter(Boolean);
  const cfg = currentPlanConfig();
  if (!cfg.bulk && clean.length > 1) {
    return clean.slice(0, 1);
  }
  return [...new Set(clean)];
}

function enforceSourceUrlLimit(){
  const cfg = currentPlanConfig();
  const raw = lines(els.urls.value);
  if (!cfg.bulk && raw.length > 1) {
    const first = normalizeInstagramUrl(raw[0]) || raw[0];
    els.urls.value = first;
    showPaidFeature("Free plan supports one Instagram source per analysis. Upgrade to unlock Bulk URL Manager and multiple source URLs.");
  }
}

async function resetAnalysis(){
  leads = [];
  logs = [];
  running = false;
  paused = false;
  els.urls.value = "";
  els.trades.value = "";
  els.includeWords.value = "";
  els.excludeWords.value = "";
  if (els.countryFilter) els.countryFilter.value = "";
  if (els.stateFilter) els.stateFilter.value = "";
  if (els.cityFilter) els.cityFilter.value = "";
  if (els.requireLocation) els.requireLocation.checked = false;
  els.minScore.value = 35;
  els.delay.value = currentPlanConfig().minDelay;
  els.noNewLimit.value = 25;
  if (els.extractedLinks) els.extractedLinks.value = "";
  if (els.openLinksBox) els.openLinksBox.value = "";
  if (els.phase) els.phase.textContent = "Idle";
  if (els.detail) els.detail.textContent = "";
  if (els.bar) els.bar.style.width = "0%";
  ["sourcesDone","collected","scanned","matched"].forEach(id=>{ if ($(id)) $(id).textContent = "0"; });
  hideAlert();
  await chrome.storage.local.set({form:getForm(), leads:[], logs:[], running:false, extractedLinks:[], openLinks:[]});
  renderLogs();
  renderResults();
  updateDashboard({collected:0, scanned:0, matched:0});
  show("setup");
  showPaidFeature("Analysis workspace has been reset.");
}

function showAlert(t){ els.alert.textContent = t; els.alert.classList.remove("hidden"); }
function hideAlert(){ els.alert.classList.add("hidden"); }

function renderLogs(){
  els.logs.innerHTML = logs.slice(-120).map(x=>`<div class="log">${esc(x)}</div>`).join("");
  els.logs.scrollTop = els.logs.scrollHeight;
}

function renderResults(){
  const q = (els.filter.value || "").toLowerCase();
  const tf = els.tradeFilter.value;
  const targets = [...new Set(leads.flatMap(l=>l.trades || []))].sort();

  els.tradeFilter.innerHTML = '<option value="">All Targets</option>' + targets.map(t=>`<option ${t===tf?'selected':''}>${esc(t)}</option>`).join("");
  els.tradeChips.innerHTML = targets.map(t=>`<span class="chip">${esc(t)} <b>${leads.filter(l=>(l.trades||[]).includes(t)).length}</b></span>`).join("");

  let filtered = leads.filter(l=>{
    const blob = [l.username,l.fullName,l.bio,l.source,(l.trades||[]).join(" "),l.email,l.website,(l.locationMatched||[]).join(" ")].join(" ").toLowerCase();
    return (!q || blob.includes(q)) && (!tf || (l.trades||[]).includes(tf));
  });

  els.resultCount.textContent = `${filtered.length} leads`;
  renderSummary(filtered);

  const group = {};
  for (const l of filtered) {
    const leadTargets = (l.trades && l.trades.length) ? l.trades : ["Unsorted"];
    for (const t of leadTargets) {
      if (tf && t !== tf) continue;
      (group[t] ||= []).push(l);
    }
  }

  els.tables.innerHTML = Object.keys(group).sort().map(t=>{
    const rows = group[t].sort((a,b)=>(b.score||0)-(a.score||0)).map(l=>{
      const sourceText = String(l.source || "").replace(/^https?:\/\/(www\.)?instagram\.com\//i, "@").replace(/\/$/, "");
      const signalsText = [...(l.matched || []), ...(l.locationMatched || [])].slice(0,6).join(", ");
      return `<tr>
      <td class="score">${esc(l.score || 0)}</td>
      <td class="profile-cell"><a class="url" href="${esc(l.profileUrl)}" target="_blank" title="${esc(l.profileUrl)}">@${esc(l.username)}</a></td>
      <td class="bio"><b>${esc(cleanDisplayName(l))}</b><br>${esc(cleanBio(l).slice(0,220))}</td>
      <td class="signals-cell" title="${esc(signalsText)}">${esc(signalsText)}</td>
      <td class="source-cell" title="${esc(l.source || "")}">${esc(sourceText)}</td>
    </tr>`;
    }).join("");

    return `<div class="trade-card">
      <div class="trade-head"><span>${esc(t)}</span><span>${group[t].length} leads</span></div>
      <div class="table-wrap">
        <table class="lead-table">
          <thead><tr><th>Score</th><th>Profile</th><th>Name / Bio</th><th>Signals</th><th>Source</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
  }).join("") || '<div class="notice">No results yet. Start an analysis to generate targeted leads.</div>';
}

function renderSummary(items){
  const total = items.length;
  const avgScore = total ? Math.round(items.reduce((s,l)=>s+(Number(l.score)||0),0)/total) : 0;
  const targets = new Set(items.flatMap(l=>l.trades||[])).size;
  const contacts = items.filter(l=>/(mailto:|@|\.com|\.co|\.net|\.org)/i.test([l.bio,l.website,l.email].join(" "))).length;
  els.summaryCards.innerHTML = [
    ["Total Leads", total],
    ["Average Score", avgScore],
    ["Target Groups", targets],
    ["Public Contact Signals", contacts]
  ].map(([a,b])=>`<div class="summary-card"><span>${a}</span><b>${b}</b></div>`).join("");

  const topTargets = [...new Set(items.flatMap(l=>l.trades||[]))].slice(0,4).join(", ") || "No target matches yet";
  const highIntent = items.filter(l => Number(l.score || 0) >= 70).length;
  const verified = items.filter(l => cleanBio(l) !== "No public bio captured.").length;
  if ($("leadInsights")) $("leadInsights").innerHTML = `
    <div class="insight-block"><span>Lead Quality</span><b>${highIntent} high-intent</b><small>Profiles scoring 70+ based on target keywords and bio signals.</small></div>
    <div class="insight-block"><span>Top Targets</span><b>${esc(topTargets)}</b><small>Use the target filter to review each segment quickly.</small></div>
    <div class="insight-block"><span>Bio Coverage</span><b>${verified}/${total}</b><small>Profiles with usable public bio text captured during analysis.</small></div>`;
}

function updateDashboard(snapshot={}){
  const scanned = snapshot.scanned ?? leads.length;
  const collected = snapshot.collected ?? Number(els.collected?.textContent || 0) ?? 0;
  const matched = snapshot.matched ?? leads.length;
  const contacts = leads.filter(l=>/(mailto:|@|\.com|\.co|\.net|\.org)/i.test([l.bio,l.website,l.email].join(" "))).length;
  $("dashScanned").textContent = scanned || leads.length || 0;
  $("dashCollected").textContent = collected || leads.length || 0;
  $("dashMatched").textContent = matched || leads.length || 0;
  $("dashContacts").textContent = contacts || 0;
}

async function clearResults(){
  leads = []; logs = [];
  await chrome.storage.local.set({leads, logs});
  renderResults(); renderLogs(); updateDashboard();
}

function exportCSV(){
  const head = ["target","username","profile_url","score","full_name","bio","matched_signals","location_signals","source"];
  const rows = [head.join(",")];
  for (const l of leads) {
    for (const t of (l.trades || [""])) {
      rows.push([t,l.username,l.profileUrl,l.score,l.fullName,l.bio,(l.matched||[]).join(" | "),(l.locationMatched||[]).join(" | "),l.source].map(csv).join(","));
    }
  }
  downloadFile(`qevanta-leads-${dateStamp()}.csv`, rows.join("\r\n"), "text/csv");
}

function exportExcel(){
  const head = ["Target","Username","Profile URL","Score","Full Name","Bio","Matched Signals","Location Signals","Source"];
  const body = leads.flatMap(l => (l.trades || [""]).map(t => [t,l.username,l.profileUrl,l.score,l.fullName,l.bio,(l.matched||[]).join(" | "),(l.locationMatched||[]).join(" | "),l.source]));
  const html = `<table><thead><tr>${head.map(h=>`<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${
    body.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")
  }</tbody></table>`;
  downloadFile(`qevanta-leads-${dateStamp()}.xls`, html, "application/vnd.ms-excel");
}

function copyURLs(){
  navigator.clipboard.writeText([...new Set(leads.map(l=>l.profileUrl).filter(Boolean))].join("\n"));
}

function downloadFile(name, content, type){
  const blob = new Blob([content], {type});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

function cleanBulkUrls(){
  if (!currentPlanConfig().bulk) return showPaidFeature("Bulk URL Manager is locked on the Free plan.");
  const clean = [...new Set(lines(els.bulkUrls.value).map(normalizeInstagramUrl).filter(Boolean))];
  els.bulkUrls.value = clean.join("\n");
  chrome.storage.local.set({bulkUrls:clean});
}

function importBulkToAnalysis(){
  if (!currentPlanConfig().bulk) return showPaidFeature("Importing bulk URLs requires any paid plan.");
  cleanBulkUrls();
  els.urls.value = els.bulkUrls.value;
  saveForm();
  show("setup");
}

async function openAllBulkTabs(){
  if (!currentPlanConfig().bulk) return showPaidFeature("Opening bulk source URLs requires any paid plan.");
  cleanBulkUrls();
  const cfg = currentPlanConfig();
  const urls = lines(els.bulkUrls.value);
  const max = cfg.openLimit >= 9999 ? urls.length : cfg.openLimit;
  if (urls.length > max) showPaidFeature(`${cfg.name} plan can open ${max} links per batch. Upgrade for larger batches.`);
  for (const url of urls.slice(0,max)) await chrome.tabs.create({url, active:false});
}

async function saveCurrentList(){
  if (!currentPlanConfig().bulk) return showPaidFeature("Saving URL lists requires any paid plan.");
  cleanBulkUrls();
  const name = els.listName.value.trim() || `Saved List ${new Date().toLocaleDateString()}`;
  const urls = lines(els.bulkUrls.value);
  if (!urls.length) return;
  const data = await chrome.storage.local.get(["savedLists"]);
  const savedLists = data.savedLists || [];
  savedLists.unshift({id:Date.now(), name, urls, createdAt:new Date().toISOString()});
  await chrome.storage.local.set({savedLists});
  els.listName.value = "";
  renderSavedLists(savedLists);
}

function renderSavedLists(savedLists){
  if (!savedLists.length) {
    els.savedLists.innerHTML = '<div class="notice">No saved lists yet.</div>';
    return;
  }
  els.savedLists.innerHTML = savedLists.map(item=>`<div class="saved-item">
    <div><b>${esc(item.name)}</b><small>${item.urls.length} URLs</small></div>
    <div class="actions">
      <button data-load="${item.id}">Load</button>
      <button data-delete="${item.id}" class="danger">Delete</button>
    </div>
  </div>`).join("");

  els.savedLists.querySelectorAll("[data-load]").forEach(btn=>btn.onclick=async()=>{
    const data = await chrome.storage.local.get(["savedLists"]);
    const item = (data.savedLists || []).find(x=>String(x.id)===String(btn.dataset.load));
    if (item) { els.bulkUrls.value = item.urls.join("\n"); await chrome.storage.local.set({bulkUrls:item.urls}); }
  });

  els.savedLists.querySelectorAll("[data-delete]").forEach(btn=>btn.onclick=async()=>{
    const data = await chrome.storage.local.get(["savedLists"]);
    const updated = (data.savedLists || []).filter(x=>String(x.id)!==String(btn.dataset.delete));
    await chrome.storage.local.set({savedLists:updated});
    renderSavedLists(updated);
  });
}

async function mockLogin(){
  const email = $("loginEmail").value.trim() || "demo@qevanta.co";
  const user = {email, name:email.split("@")[0]};
  const plan = {name:"FREE", credits:100};
  await chrome.storage.local.set({mockUser:user, plan});
  const data = await chrome.storage.local.get(["deviceId"]);
  updateAccountUI(user, plan, data.deviceId);
}

async function mockLogout(){
  await chrome.storage.local.remove(["mockUser"]);
  const data = await chrome.storage.local.get(["deviceId"]);
  updateAccountUI(null, {name:"FREE", credits:100}, data.deviceId);
}

function updateAccountUI(user, plan, deviceId){
  $("planName").textContent = plan.name || "FREE";
  $("creditsLeft").textContent = plan.credits ?? 100;
  $("securityUser").textContent = user?.email || "Guest";
  $("securityPlan").textContent = plan.name || "FREE";
  $("deviceId").textContent = deviceId || "Generating...";
  $("licenseStatus").textContent = user ? "ACTIVE" : "ACTIVE";
  updateOpenLimitUI?.();
  updatePlanLocks?.();
}

function generateDeviceId(){
  const arr = new Uint32Array(4);
  crypto.getRandomValues(arr);
  return "qv-" + [...arr].map(x=>x.toString(16)).join("-");
}

async function toggleTheme(){
  const isLight = document.body.classList.toggle("light");
  const theme = isLight ? "light" : "dark";
  $("btnTheme").textContent = isLight ? "Light" : "Dark";
  await chrome.storage.local.set({theme});
}

function applyTheme(theme){
  document.body.classList.toggle("light", theme === "light");
  $("btnTheme").textContent = theme === "light" ? "Light" : "Dark";
}


function mergeLeads(a, b){
  const map = new Map();
  [...(a||[]), ...(b||[])].forEach(l => {
    if (l && (l.profileUrl || l.username)) map.set(l.profileUrl || l.username, l);
  });
  return [...map.values()];
}

function showStopModal(msg={}){
  $("stopMatched").textContent = leads.length || msg.matched || 0;
  $("stopScanned").textContent = msg.scanned || 0;
  $("stopCollected").textContent = msg.collected || 0;
  $("stopModal").classList.remove("hidden");
}

function closeStopModal(){
  $("stopModal").classList.add("hidden");
}

async function extractLeadLinks(){
  const urls = uniqueLinksFromLeads();
  if (!urls.length) {
    show("links");
    els.extractedLinks.value = "";
    els.linksCount.textContent = "0 links extracted from your current results.";
    return;
  }
  els.extractedLinks.value = urls.join("\n");
  els.linksCount.textContent = `${urls.length} lead links extracted.`;
  await chrome.storage.local.set({extractedLinks:urls});
  show("links");
}

function uniqueLinksFromLeads(){
  return [...new Set(leads.map(l => normalizeInstagramUrl(l.profileUrl || (l.username ? `https://www.instagram.com/${l.username}/` : ""))).filter(Boolean))];
}

function exportLinksCSV(){
  const urls = lines(els.extractedLinks.value);
  const rows = ["profile_url", ...urls.map(csv)];
  downloadFile(`qevanta-lead-links-${dateStamp()}.csv`, rows.join("\r\n"), "text/csv");
}

async function copyExtractedLinks(){
  const urls = lines(els.extractedLinks.value);
  await navigator.clipboard.writeText(urls.join("\n"));
  els.linksCount.textContent = `${urls.length} links copied to clipboard.`;
}

async function sendLinksToOpener(){
  const urls = lines(els.extractedLinks.value).map(normalizeInstagramUrl).filter(Boolean);
  els.openLinksBox.value = urls.join("\n");
  await chrome.storage.local.set({openLinks:urls});
  updateOpenLimitUI();
  show("openlinks");
}

function getPlan(){
  const cfg = currentPlanConfig();
  return {name:cfg.name, limit:cfg.openLimit};
}

function currentPlanConfig(){
  const realPlan =
    window.QEVANTA_USER?.plan?.id ||
    window.QEVANTA_USER?.plan?.name ||
    window.QEVANTA_USER?.profile?.plan ||
    $("planName")?.textContent ||
    "FREE";

  const name = String(realPlan).toUpperCase();
  return PLAN_CONFIG[name] || PLAN_CONFIG.FREE;
}

async function previewPlan(name){
  const cfg = PLAN_CONFIG[String(name || "FREE").toUpperCase()] || PLAN_CONFIG.FREE;
  const user = {email:$("loginEmail")?.value?.trim() || "demo@qevanta.co", name:"Preview"};
  await chrome.storage.local.set({mockUser:user, plan:{name:cfg.name, credits:cfg.credits}});
  const data = await chrome.storage.local.get(["deviceId"]);
  updateAccountUI(user, {name:cfg.name, credits:cfg.credits}, data.deviceId);
}

function updatePlanLocks(){
  const cfg = currentPlanConfig();
  const bulkLocked = !cfg.bulk;
  $("navBulk")?.classList.toggle("locked", bulkLocked);
  $("btnLoadBulk")?.classList.toggle("locked", bulkLocked);
  $("btnLoadBulk").style.display = bulkLocked ? "none" : "";
  if (els.bulkLocked) els.bulkLocked.classList.toggle("hidden", !bulkLocked);
  if (els.bulkContent) els.bulkContent.classList.toggle("disabled-panel", bulkLocked);

  if ($("delay")) {
    $("delay").min = cfg.minDelay;
    if (Number($("delay").value || 0) < cfg.minDelay) $("delay").value = cfg.minDelay;
    $("delay").disabled = ["TRIAL","FREE"].includes(cfg.name);
    $("delay").classList.toggle("locked-input", ["TRIAL","FREE"].includes(cfg.name));
  }
  if ($("openDelay")) {
    $("openDelay").min = cfg.minDelay;
    if (Number($("openDelay").value || 0) < cfg.minDelay) $("openDelay").value = cfg.minDelay;
    $("openDelay").classList.toggle("locked-input", cfg.name === "FREE");
  }
  if ($("planRulesNotice")) {
    const limit = cfg.scanLimit >= 999999 ? "all available followers/following from each source profile" : `${cfg.scanLimit} collected profiles`;
    $("planRulesNotice").textContent = `${cfg.label} plan scans up to ${limit} per analysis. ${cfg.bulk ? "Bulk URL Manager is unlocked." : "Bulk URL Manager, faster controls, and larger scan limits unlock on paid plans."}`;
  }
  if ($("scanCapText")) $("scanCapText").textContent = cfg.scanLimit >= 999999 ? "All available" : `${cfg.scanLimit} profiles`;
  if ($("bulkCapText")) $("bulkCapText").textContent = cfg.bulk ? "Unlocked" : "Paid only";
  if ($("speedCapText")) $("speedCapText").textContent = `${cfg.minDelay}ms`;
  if (els.urls) {
    els.urls.rows = cfg.bulk ? 5 : 3;
    els.urls.placeholder = cfg.bulk ? "https://www.instagram.com/example/\nhttps://www.instagram.com/anotherprofile/" : "https://www.instagram.com/example/";
    enforceSourceUrlLimit();
  }
  const paidLocation = cfg.name !== "FREE";
  ["countryFilter","stateFilter","cityFilter","requireLocation"].forEach(id => {
    const el = $(id);
    if (!el) return;
    el.disabled = !paidLocation;
    el.classList.toggle("locked-input", !paidLocation);
  });
  $("locationPanel")?.classList.toggle("disabled-panel", !paidLocation);
  updateOpenLimitUI?.();
}

function showPaidFeature(message){
  if ($("upgradeMessage")) {
    const cfg = currentPlanConfig();
    const found = Array.isArray(leads) ? leads.length : 0;
    const visible = Math.min(found, cfg.visibleLeads || found);
    const locked = Math.max(0, found - visible);
    $("upgradeMessage").textContent = message || (locked > 0 ? `You found ${found} leads. ${visible} visible, ${locked} locked. Upgrade to unlock all leads.` : "This feature requires a paid plan.");
  }
  if ($("upgradeModal")) $("upgradeModal").classList.remove("hidden");
  const box = document.createElement("div");
  box.className = "toast";
  box.textContent = message || "This feature requires a paid plan.";
  document.body.appendChild(box);
  setTimeout(()=>box.remove(), 2600);
}

function closeUpgradeModal(){
  $("upgradeModal")?.classList.add("hidden");
}

function updateOpenLimitUI(){
  const plan = getPlan();
  const label = plan.limit >= 9999 ? "unlimited" : plan.limit;
  els.openLinksLimitText.textContent = `${plan.name} plan can open ${label} links at a time.`;
  const batch = $("openBatch");
  if (batch && plan.limit < 9999 && Number(batch.value || 0) > plan.limit) {
    batch.value = plan.limit;
    if (currentView === "openlinks") showPaidFeature(`${plan.name} plan is limited to ${plan.limit} links per batch.`);
  }
  if ($("openDelay")) {
    $("openDelay").min = currentPlanConfig().minDelay;
    if (["TRIAL","FREE"].includes(currentPlanConfig().name) && Number($("openDelay").value || 0) < currentPlanConfig().minDelay) $("openDelay").value = currentPlanConfig().minDelay;
  }
}

function cleanOpenLinks(){
  const clean = [...new Set(lines(els.openLinksBox.value).map(normalizeInstagramUrl).filter(Boolean))];
  els.openLinksBox.value = clean.join("\n");
  chrome.storage.local.set({openLinks:clean});
  updateOpenLimitUI();
}

async function openLinksBatch(){
  cleanOpenLinks();
  const all = lines(els.openLinksBox.value);
  const plan = getPlan();
  const start = Math.max(1, Number($("openStart").value || 1));
  let batch = Math.max(1, Number($("openBatch").value || plan.limit));
  if (plan.limit < 9999 && batch > plan.limit) {
    showPaidFeature(`${plan.name} plan can open only ${plan.limit} links at a time. Upgrade to open larger batches.`);
    batch = plan.limit;
  }
  const delay = Math.max(0, Number($("openDelay").value || 0));
  const selected = all.slice(start - 1, start - 1 + batch);
  if (!selected.length) {
    els.openLinksStatus.textContent = "No links available in this batch.";
    return;
  }
  for (const url of selected) {
    await chrome.tabs.create({url, active:false});
    if (delay) await new Promise(r => setTimeout(r, delay));
  }
  $("openStart").value = start + selected.length;
  els.openLinksStatus.textContent = `Opened ${selected.length} links. Next batch starts from #${start + selected.length}.`;
}


function enforceOpenBatchLimit(){
  const cfg = currentPlanConfig();
  const el = $("openBatch");
  if (!el) return;
  const n = Number(el.value || 0);
  if (cfg.openLimit < 9999 && n > cfg.openLimit) {
    el.value = cfg.openLimit;
    showPaidFeature(`${cfg.name} plan can open only ${cfg.openLimit} links at a time.`);
  }
}

function enforceDelayLimit(){
  const cfg = currentPlanConfig();
  ["delay","openDelay"].forEach(id=>{
    const el = $(id);
    if (!el) return;
    const n = Number(el.value || 0);
    if (n && n < cfg.minDelay) {
      el.value = cfg.minDelay;
      showPaidFeature(`${cfg.label} plan minimum safe delay is ${cfg.minDelay}ms. Upgrade to unlock faster settings.`);
    }
  });
}

function cleanDisplayName(l){
  const name = String(l.fullName || "").trim();
  const username = String(l.username || "").trim();
  const source = String(l.source || "").replace(/^@/, "").trim();

  // Sometimes Instagram's dynamic list/modal leaks the signed-in/source account
  // into nearby row text. Do not show that under a lead's Name/Bio column.
  const compactName = name.toLowerCase().replace(/[^a-z0-9._]/g, "");
  const compactSource = source.toLowerCase().replace(/[^a-z0-9._]/g, "");
  const compactUser = username.toLowerCase().replace(/[^a-z0-9._]/g, "");

  if (!name) return "Profile name not captured";
  if (compactName === compactUser) return "Profile name not captured";
  if (compactSource && (compactName === compactSource || compactName.includes(compactSource))) return "Profile name not captured";
  if (/home|explore|reels|notifications|messages|instagram/i.test(name) && name.length > 40) return "Profile name not captured";
  if (name.length > 80 && !/\s/.test(name)) return "Profile name not captured";
  return name;
}

function cleanBio(l){
  const bio = String(l.bio || "").trim();
  const source = String(l.source || "").replace(/^@/, "").trim().toLowerCase();
  if (!bio) return "Open profile to verify public bio.";
  if (source && bio.toLowerCase().includes(source) && bio.length < 80) return "Open profile to verify public bio.";
  if (/home|explore|reels|notifications|messages/i.test(bio) && bio.length > 120) return "Bio not captured cleanly. Open profile to verify.";
  return bio;
}

function csv(v){ return `"${String(v || "").replace(/"/g,'""')}"`; }
function esc(s){ return String(s || "").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
function debounce(fn,ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
function dateStamp(){ return new Date().toISOString().slice(0,10); }



async function bootQevantaAuth(){
  const saved = await chrome.storage.local.get(["qevantaSession"]);

  if(saved.qevantaSession?.access_token){
    $("authScreen")?.classList.add("hidden");
    $("appRoot")?.classList.remove("hidden");
    await loadQevantaUserPlan(saved.qevantaSession);
    init();
    return;
  }

  $("authScreen")?.classList.remove("hidden");
  $("appRoot")?.classList.add("hidden");
}

async function qevantaSignup(){
  const email = $("authEmail")?.value?.trim();
  const password = $("authPassword")?.value?.trim();
  const msg = $("authMsg");

  if(!email || !password){
    if(msg) msg.textContent = "Please enter email and password.";
    return;
  }

  if(msg) msg.textContent = "Creating account...";

  const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      "apikey":SUPABASE_ANON_KEY
    },
    body:JSON.stringify({ email, password })
  });

  const data = await res.json();

  if(!res.ok){
    if(msg) msg.textContent = data.error_description || data.msg || "Signup failed.";
    return;
  }

  if(msg) msg.textContent = "Account created. Please login to continue.";
}

async function qevantaLogin(){
  const email = $("authEmail")?.value?.trim();
  const password = $("authPassword")?.value?.trim();
  const msg = $("authMsg");

  if(!email || !password){
    if(msg) msg.textContent = "Please enter email and password.";
    return;
  }

  if(msg) msg.textContent = "Logging in...";

  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      "apikey":SUPABASE_ANON_KEY
    },
    body:JSON.stringify({ email, password })
  });

  const data = await res.json();

  if(!res.ok){
    if(msg) msg.textContent = data.error_description || data.msg || "Login failed.";
    return;
  }

  await chrome.storage.local.set({ qevantaSession:data });

  $("authScreen")?.classList.add("hidden");
  $("appRoot")?.classList.remove("hidden");

  await loadQevantaUserPlan(data);
  init();
}

async function qevantaLogout(){
  await chrome.storage.local.remove(["qevantaSession"]);
  location.reload();
}

async function loadQevantaUserPlan(session){
  try{
    const userId = session.user.id;
    const token = session.access_token;

    const profileRes = await fetch(`${SUPABASE_URL}/rest/v1/qevanta_profiles?id=eq.${userId}&select=*`, {
      headers:{
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${token}`
      }
    });

    const profileData = await profileRes.json();
    const profile = profileData[0];

    if(!profile){
      alert("Profile not found. Please contact Qevanta support.");
      return;
    }

    if(profile.plan === "trial" && profile.trial_ends_at){
      const trialEnded = new Date(profile.trial_ends_at).getTime() < Date.now();
      if(trialEnded){
        alert("Your trial has expired. Please upgrade to continue.");
        await qevantaLogout();
        return;
      }
    }

    const planRes = await fetch(`${SUPABASE_URL}/rest/v1/qevanta_plans?id=eq.${profile.plan}&select=*`, {
      headers:{
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${token}`
      }
    });

    const planData = await planRes.json();
    const plan = planData[0] || {id:profile.plan,name:profile.plan};

    window.QEVANTA_USER = {
      id:userId,
      email:session.user.email,
      profile,
      plan
    };

    const cfg = PLAN_CONFIG[String(profile.plan || "free").toUpperCase()] || PLAN_CONFIG.FREE;
    const limit = cfg.credits === "Unlimited" ? "Unlimited" : Math.max(Number(cfg.credits || 0) - Number(profile.credits_used || 0), 0);

    if($("planName")) $("planName").textContent = cfg.name;
    if($("creditsLeft")) $("creditsLeft").textContent = limit;
    if($("accountCredits")) $("accountCredits").textContent = limit;
    if($("securityUser")) $("securityUser").textContent = session.user.email;
    if($("securityPlan")) $("securityPlan").textContent = cfg.name;
    if($("licenseStatus")) $("licenseStatus").textContent = (profile.account_status || "ACTIVE").toUpperCase();

    updateOpenLimitUI?.();
    updatePlanLocks?.();
  }catch(err){
    console.error("Qevanta plan load failed", err);
  }
}

function canScanMore(){
  const user = window.QEVANTA_USER;
  if(!user || !user.profile) return true;

  const cfg = currentPlanConfig();
  if(cfg.credits === "Unlimited") return true;

  const used = Number(user.profile.credits_used || 0);
  const limit = Number(cfg.credits || cfg.scanLimit || 0);

  return used < limit;
}

document.addEventListener("DOMContentLoaded", () => {
  $("loginBtn")?.addEventListener("click", qevantaLogin);
  $("signupBtn")?.addEventListener("click", qevantaSignup);
});
