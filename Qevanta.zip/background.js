"use strict";

let S = {
  running:false, paused:false, stop:false, tabId:null,
  collected:0, scanned:0, matched:0, sourcesDone:0,
  leads:[], seen:new Set()
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START") { start(msg); sendResponse({ok:true}); return true; }
  if (msg.type === "PAUSE") { S.paused=true; send({type:"PAUSED"}); sendResponse({ok:true}); return true; }
  if (msg.type === "RESUME") { S.paused=false; send({type:"RESUMED"}); sendResponse({ok:true}); return true; }
  if (msg.type === "STOP") { S.stop=true; S.running=false; send({type:"STOPPED",leads:S.leads,collected:S.collected,scanned:S.scanned,matched:S.matched,sourcesDone:S.sourcesDone}); sendResponse({ok:true}); return true; }
});

async function start(cfg) {
  if (S.running) return;
  S = {running:true, paused:false, stop:false, tabId:null, collected:0, scanned:0, matched:0, sourcesDone:0, leads:[], seen:new Set()};

  const trades = buildTrades(cfg.trades || []);
  const include = (cfg.includeWords || []).map(x => x.toLowerCase().trim()).filter(Boolean);
  const exclude = (cfg.excludeWords || []).map(x => x.toLowerCase().trim()).filter(Boolean);
  const location = normalizeLocationConfig(cfg.location || {});
  const planMinDelay = {FREE:900, STARTER:500, PRO:300, AGENCY:100}[String(cfg.plan || "FREE").toUpperCase()] || 900;
  const delay = Math.max(planMinDelay, Number(cfg.delay || planMinDelay));
  const maxProfiles = Number(cfg.maxProfiles || 300);
  const noNewLimit = Math.max(8, Number(cfg.noNewLimit || 30));

  try {
    log("Qevanta analysis started. Keep the Instagram worker tab open and active.");
    const all = [];

    for (let i=0; i<cfg.urls.length && !S.stop; i++) {
      await pausePoint();
      const username = userFromUrl(cfg.urls[i]);
      if (!username) { log("Bad URL skipped: " + cfg.urls[i]); continue; }

      progress("Opening audience list", `@${username} ${cfg.listType}`, 0);
      const remainingLimit = maxProfiles >= 999999 ? 999999 : Math.max(0, maxProfiles - all.length);
      if (remainingLimit <= 0) { log("Plan scan limit reached before opening next source."); break; }
      const accounts = await collectAllChunked(username, cfg.listType, delay, noNewLimit, remainingLimit);
      S.sourcesDone++;
      log(`@${username}: ${accounts.length} usernames collected`);

      for (const a of accounts) {
        if (!S.seen.has(a.username)) {
          S.seen.add(a.username);
          all.push({...a, source:"@" + username});
        }
      }
      S.collected = all.length;
      progress("Audience collection complete", `${all.length} unique usernames collected`, 100);
    }

    if (maxProfiles > 0 && all.length > maxProfiles) {
      log(`Plan limit applied: analyzing first ${maxProfiles} of ${all.length} collected usernames.`);
      all.splice(maxProfiles);
      S.collected = all.length;
    }

    log(`Total unique usernames ready for profile analysis: ${all.length}`);

    for (let i=0; i<all.length && !S.stop; i++) {
      await pausePoint();
      const a = all[i];
      const pct = all.length ? Math.round(((i + 1) / all.length) * 100) : 0;
      progress("Finding matched results", `@${a.username} (${i+1}/${all.length})`, pct);

      const p = await scanProfile(a.username, delay);
      S.scanned++;

      const profile = {
        ...a, ...p,
        profileUrl: `https://www.instagram.com/${a.username}/`
      };

      const result = score(profile, trades, include, exclude, location);
      if (result.ok && result.score >= Number(cfg.minScore || 35)) {
        const lead = {...profile, score:result.score, trades:result.trades, matched:result.matched, locationMatched:result.locationMatched || []};
        S.leads.push(lead);
        S.matched++;
        send({type:"LEAD", lead});
        log(`MATCH ${result.score}: @${a.username} → ${result.trades.join(", ")}`);
      }

      if ((i+1) % 10 === 0) log(`Profiles scanned ${i+1}/${all.length} | matched ${S.matched}`);
      await sleep(delay);
    }

    if (S.stop) {
      progress("Stopped", `${S.scanned} scanned · ${S.matched} matched saved`, 100);
      send({type:"STOPPED", leads:S.leads, collected:S.collected, scanned:S.scanned, matched:S.matched, sourcesDone:S.sourcesDone});
    } else {
      progress("Done", `${S.scanned} scanned · ${S.matched} matched`, 100);
      send({type:"DONE", leads:S.leads});
    }
  } catch (e) {
    log("ERROR: " + (e.message || String(e)));
    send({type:"ERROR", message:e.message || String(e)});
  } finally {
    S.running = false;
  }
}

/* ------------------ NEW CHUNKED FOLLOW/FOLLOWING COLLECTOR ------------------ */

async function collectAllChunked(username, listType, delay, noNewLimit, maxCollect=999999) {
  const tab = await openWorker(`https://www.instagram.com/${username}/`);
  await waitLoad(tab.id, 15000);
  await sleep(3000);

  // 1) Open the native followers/following modal by clicking the real Instagram link.
  let opened = await chrome.scripting.executeScript({
    target: {tabId: tab.id},
    func: injectedOpenListModal,
    args: [{username, listType}]
  });

  let openRes = opened?.[0]?.result || {};
  log(`Open list: ${openRes.status || "unknown"} ${openRes.detail || ""}`);

  await sleep(2500);

  // 2) Initialize collection state.
  await chrome.scripting.executeScript({
    target: {tabId: tab.id},
    func: injectedInitCollector,
    args: [{username, listType}]
  });

  const merged = new Map();
  let noGrowRounds = 0;
  let lastCount = 0;
  let round = 0;

  while (!S.stop) {
    await pausePoint();
    round++;

    const res = await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      func: injectedCollectChunk,
      args: [{username, listType, delay, steps: 12}]
    });

    const data = res?.[0]?.result || {accounts:[], done:false, count:0, note:"no-result"};
    for (const a of data.accounts || []) {
      if (a && a.username && merged.size < maxCollect) merged.set(a.username, a);
    }

    S.collected = S.seen.size + merged.size;
    const collectPct = maxCollect >= 999999 ? Math.min(95, Math.max(2, Math.round((noGrowRounds / Math.max(1, noNewLimit)) * 95))) : Math.min(100, Math.round((merged.size / Math.max(1, maxCollect)) * 100));
    progress("Collecting usernames", `@${username}: ${merged.size} collected | ${data.note || ""}`, collectPct);

    if (merged.size > lastCount) {
      noGrowRounds = 0;
      lastCount = merged.size;
      log(`Collecting @${username}: ${merged.size} usernames`);
    } else {
      noGrowRounds++;
    }

    // Stop when plan collection limit is reached, or after many repeated rounds with zero growth.
    if (merged.size >= maxCollect) { log(`Plan collection limit reached for @${username}: ${merged.size} usernames.`); break; }
    if (data.done && noGrowRounds >= Math.ceil(noNewLimit / 3)) break;
    if (noGrowRounds >= noNewLimit) break;

    await sleep(Math.max(500, delay));
  }

  return [...merged.values()];
}

function injectedOpenListModal({username, listType}) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function normPath(href) {
    try { return href.startsWith("http") ? new URL(href).pathname : href; }
    catch(e) { return href || ""; }
  }

  function realClick(el) {
    if (!el) return false;
    el.scrollIntoView({block:"center", inline:"center"});
    const opts = {bubbles:true, cancelable:true, view:window};
    el.dispatchEvent(new MouseEvent("mouseover", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.dispatchEvent(new MouseEvent("click", opts));
    return true;
  }

  // Close old dialog if any.
  try {
    const closeBtn = document.querySelector('div[role="dialog"] button[aria-label="Close"], div[role="dialog"] svg[aria-label="Close"]')?.closest("button");
    if (closeBtn) closeBtn.click();
  } catch(e) {}

  // Always go to clean profile route first.
  if (!location.pathname.match(new RegExp("^/" + username + "/?$", "i"))) {
    history.pushState({}, "", "/" + username + "/");
    window.dispatchEvent(new PopStateEvent("popstate"));
  }

  const wanted = `/${username}/${listType}/`.toLowerCase();
  const links = [...document.querySelectorAll('a[href]')];

  // Best: exact href /username/following/
  let link = links.find(a => normPath(a.getAttribute("href") || "").toLowerCase() === wanted);

  // Good: href ends /following/
  if (!link) {
    link = links.find(a => {
      const p = normPath(a.getAttribute("href") || "").toLowerCase();
      return p.includes(`/${username.toLowerCase()}/${listType}/`) || p.endsWith(`/${listType}/`);
    });
  }

  // Fallback: statistic link text contains followers/following.
  if (!link) {
    const key = listType.toLowerCase();
    link = [...document.querySelectorAll("a,button")].find(el => {
      const t = (el.textContent || "").toLowerCase().replace(/\s+/g, " ").trim();
      return t.includes(key) && t.length < 80;
    });
  }

  if (link) {
    realClick(link);
    return {status:"clicked", detail:(link.textContent || link.getAttribute("href") || "").trim().slice(0,80)};
  }

  // Last fallback: navigate to the route.
  location.href = `https://www.instagram.com/${username}/${listType}/`;
  return {status:"navigated", detail:"link not found"};
}

function injectedInitCollector({username, listType}) {
  window.__IGLF = {
    username, listType,
    accounts: {},
    noNew: 0,
    lastCount: 0,
    lastHeight: 0,
    rounds: 0
  };
  return {ok:true};
}

async function injectedCollectChunk({username, listType, delay, steps}) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  if (!window.__IGLF) {
    window.__IGLF = {username, listType, accounts:{}, noNew:0, lastCount:0, lastHeight:0, rounds:0};
  }
  const ST = window.__IGLF;

  function isUserHref(href) {
    try {
      const p = href.startsWith("http") ? new URL(href).pathname : href;
      if (/^\/(p|reel|reels|stories|explore|accounts|direct|about|legal|challenge|graphql|api|developer|privacy|terms)\b/i.test(p)) return false;
      const parts = p.replace(/^\/|\/$/g, "").split("/");
      return parts.length === 1 && /^[A-Za-z0-9_.]{1,30}$/.test(parts[0]);
    } catch(e) { return false; }
  }

  function uname(href) {
    const p = href.startsWith("http") ? new URL(href).pathname : href;
    return p.replace(/^\/|\/$/g, "").split("/")[0];
  }

  function getNameNear(a, u) {
    const row = a.closest('[role="listitem"], li, div[style*="height"], div') || a.parentElement;
    if (!row) return "";
    const texts = [...row.querySelectorAll("span,div")]
      .map(x => (x.textContent || "").trim())
      .filter(t => t && t !== u && t.length < 120 && !/^(follow|following|requested|remove|message)$/i.test(t));
    return [...new Set(texts)].slice(0,3).join(" ").slice(0,140);
  }

  function harvest(root) {
    let added = 0;
    const anchors = [...root.querySelectorAll('a[href]')];
    for (const a of anchors) {
      const h = a.getAttribute("href") || "";
      if (!isUserHref(h)) continue;
      const u = uname(h);
      if (!u || u.toLowerCase() === username.toLowerCase()) continue;
      if (!ST.accounts[u]) {
        ST.accounts[u] = {
          username: u,
          fullName: getNameNear(a, u),
          profileUrl: "https://www.instagram.com/" + u + "/"
        };
        added++;
      }
    }
    return added;
  }

  function findRoot() {
    const dialog = document.querySelector('div[role="dialog"]');
    if (dialog) return dialog;

    // If Instagram uses route page instead of dialog, use main/body.
    return document.querySelector("main") || document.body;
  }

  function findScroller(root) {
    const candidates = [root, ...root.querySelectorAll("*")];
    let best = null;
    let bestScore = -1;

    for (const el of candidates) {
      const rect = el.getBoundingClientRect();
      if (rect.height < 180 || rect.width < 180) continue;

      const overflow = getComputedStyle(el).overflowY;
      const scrollable = (overflow === "auto" || overflow === "scroll" || el.scrollHeight > el.clientHeight + 80);
      if (!scrollable) continue;

      const links = el.querySelectorAll('a[href^="/"], a[href^="https://www.instagram.com/"]').length;
      const score = (el.scrollHeight - el.clientHeight) + links * 80 + rect.height;
      if (score > bestScore) {
        best = el;
        bestScore = score;
      }
    }

    return best || document.scrollingElement || document.documentElement || document.body;
  }

  function hardScroll(scroller) {
    try { scroller.focus?.(); } catch(e) {}
    try { scroller.scrollTop += Math.max(700, scroller.clientHeight * 0.95); } catch(e) {}
    try { scroller.scrollBy?.({top: Math.max(700, scroller.clientHeight * 0.95), behavior:"instant"}); } catch(e) {}
    try { scroller.dispatchEvent(new Event("scroll", {bubbles:true})); } catch(e) {}
    try { scroller.dispatchEvent(new WheelEvent("wheel", {deltaY:2200, bubbles:true, cancelable:true})); } catch(e) {}
    try { window.dispatchEvent(new WheelEvent("wheel", {deltaY:2200, bubbles:true, cancelable:true})); } catch(e) {}
  }

  const root = findRoot();

  // If no dialog and still on profile/following page, try clicking list link again.
  if (!document.querySelector('div[role="dialog"]')) {
    const wanted = `/${username}/${listType}/`.toLowerCase();
    const link = [...document.querySelectorAll("a[href],button")].find(el => {
      const h = el.getAttribute?.("href") || "";
      const t = (el.textContent || "").toLowerCase();
      return h.toLowerCase().includes(wanted) || (t.includes(listType) && t.length < 80);
    });
    if (link) {
      try { link.click(); await sleep(1200); } catch(e) {}
    }
  }

  let note = "";
  for (let i=0; i<(steps || 10); i++) {
    ST.rounds++;
    const r = findRoot();
    harvest(r);
    harvest(document.body);

    const scroller = findScroller(r);
    const oldTop = scroller.scrollTop || 0;
    const oldHeight = scroller.scrollHeight || 0;

    hardScroll(scroller);
    await sleep(Math.max(350, delay || 800));
    harvest(r);
    harvest(document.body);

    const count = Object.keys(ST.accounts).length;
    const newHeight = scroller.scrollHeight || 0;
    const newTop = scroller.scrollTop || 0;

    if (count > ST.lastCount || newHeight > ST.lastHeight || newTop > oldTop) {
      ST.noNew = 0;
    } else {
      ST.noNew++;
    }

    ST.lastCount = count;
    ST.lastHeight = Math.max(ST.lastHeight || 0, newHeight);
    note = `round ${ST.rounds}, noNew ${ST.noNew}, top ${Math.round(newTop)}, height ${Math.round(newHeight)}`;
  }

  const accounts = Object.values(ST.accounts);
  const done = ST.noNew >= 10;
  return {accounts, count:accounts.length, done, note, hasDialog:!!document.querySelector('div[role="dialog"]')};
}

/* ------------------------ PROFILE SCAN + SCORING ------------------------ */

async function scanProfile(username, delay) {
  const tab = await openWorker(`https://www.instagram.com/${username}/`);
  await waitLoad(tab.id, 10000);
  await sleep(Math.max(1200, delay || 800));

  const res = await chrome.scripting.executeScript({
    target:{tabId:tab.id},
    func:injectedProfile,
    args:[username]
  });
  return res?.[0]?.result || {username, fullName:"", bio:""};
}

function injectedProfile(username) {
  const result = {username, fullName:"", bio:""};

  try {
    const scripts = [...document.querySelectorAll('script[type="application/json"],script')];
    for (const s of scripts) {
      const t = s.textContent || "";
      if (!t.includes("biography") && !t.includes("full_name")) continue;

      const bio = t.match(/"biography"\s*:\s*"((?:\\.|[^"\\])*)"/);
      const name = t.match(/"full_name"\s*:\s*"((?:\\.|[^"\\])*)"/);

      if (bio) result.bio = JSON.parse('"' + bio[1] + '"');
      if (name) result.fullName = JSON.parse('"' + name[1] + '"');
      if (result.bio || result.fullName) return result;
    }
  } catch(e) {}

  const header = document.querySelector("header") || document.querySelector("main") || document.body;
  const hs = [...header.querySelectorAll("h1,h2")].map(x => x.textContent.trim()).filter(Boolean);
  if (hs[0]) result.fullName = hs[0];

  const texts = [...header.querySelectorAll("span,div,p")]
    .map(x => x.textContent.trim())
    .filter(t => t.length > 15 && t.length < 700 && !/followers|following|posts/i.test(t));

  texts.sort((a,b) => b.length - a.length);
  if (texts[0]) result.bio = texts[0];

  if (!result.fullName && document.title) {
    result.fullName = document.title.split("•")[0].replace(/\(@.*$/,"").trim();
  }

  return result;
}


function buildTrades(raw) {
  const map = {
    "electrician":["electrical","electric","electricians","wiring","wireman","licensed electrician","master electrician","electrical contractor","electrician services","electrical services"],
    "electrical":["electrician","electrical contractor","electrical services","wiring","electric"],
    "electrical contractor":["electrician","electrical","electricians","wiring","electrical services","electrical company"],
    "solar installer":["solar","solar contractor","solar installation","solar energy","solar panels","pv"],
    "solar contractor":["solar","solar installer","solar installation","solar energy","pv"],
    "general contractor":["gc","construction","contractor","builder","builders","remodeling","renovation","general contracting"],
    "construction company":["construction","builder","builders","contractor","general contractor"],
    "plumber":["plumbing","drain","pipe","licensed plumber","plumbing contractor"],
    "plumbing contractor":["plumber","plumbing","drain","pipe"],
    "hvac contractor":["hvac","heating","cooling","air conditioning","ac repair","furnace"],
    "roofing contractor":["roofing","roofer","roofers","roof repair","roof replacement","shingles"],
    "roofer":["roofing","roofers","roof repair","roof replacement","roofing contractor"],
    "painting contractor":["painting","painter","painters","house painter","commercial painter"],
    "concrete contractor":["concrete","foundation","masonry","paving"],
    "landscaping":["landscape","landscaper","landscapers","lawn care","hardscaping"],
    "pool builder":["pool contractor","pool construction","pool service"],
    "fence contractor":["fencing","fence company","fence installer"],
    "deck builder":["deck contractor","decking","outdoor living"]
  };

  return raw.map(t => {
    const n = normalizeText(t);
    const base = String(t || "").toLowerCase().trim();
    const variants = new Set([base, n, ...(map[base] || []), ...(map[n] || [])]);

    // Stronger matching: add singular/plural and token-based variants so leads are not skipped
    // when profiles use "electrical", "electricians", "contractors", "roofers", etc.
    for (const v of [...variants]) {
      for (const x of expandVariant(v)) variants.add(x);
    }

    return {
      name: base || n,
      variants: [...variants].map(normalizeText).filter(Boolean)
    };
  }).filter(t => t.name);
}

function normalizeLocationConfig(location) {
  return {
    country: normalizeText(location.country || ""),
    state: normalizeText(location.state || ""),
    city: normalizeText(location.city || ""),
    require: !!location.require
  };
}

function score(profile, trades, include, exclude, location={}) {
  const rawText = [profile.username, profile.fullName, profile.bio].join(" ");
  const text = normalizeText(rawText);

  const excludes = exclude.map(normalizeText).filter(x => x && containsSignal(text, x));
  if (excludes.length) return {ok:false, score:0, trades:[], matched:[], excluded:excludes, locationMatched:[]};

  let bestScore = 0, matchedTrades = [], matched = [];

  for (const tr of trades) {
    let s = 0, hits = [];
    for (const v of tr.variants) {
      if (v && containsSignal(text, v)) {
        // Main target terms get higher score; related terms still count strongly.
        s = Math.max(s, v === normalizeText(tr.name) ? 48 : 34);
        hits.push(v);
      }
    }

    // Token fallback: if user types "general contractor", a profile saying
    // "licensed residential contractor" should still be caught.
    const targetTokens = tokenizeSignal(tr.name).filter(x => x.length >= 4);
    const tokenHits = targetTokens.filter(tok => containsSignal(text, tok));
    if (!s && targetTokens.length && tokenHits.length >= Math.min(2, targetTokens.length)) {
      s = 30 + tokenHits.length * 6;
      hits.push(...tokenHits);
    }

    if (s) {
      const bioText = normalizeText(profile.bio || "");
      const first = tokenizeSignal(tr.name)[0] || "";
      if (containsSignal(bioText, normalizeText(tr.name))) s += 15;
      if (first && containsSignal(normalizeText(profile.username || ""), first)) s += 8;
      matchedTrades.push(tr.name);
      matched.push(...hits);
      bestScore = Math.max(bestScore, s);
    }
  }

  let inc = 0;
  for (const w of include) {
    const sig = normalizeText(w);
    if (sig && containsSignal(text, sig)) { inc += 5; matched.push(sig); }
  }
  bestScore += Math.min(20, inc);

  const locationTerms = [location.country, location.state, location.city].filter(Boolean);
  const locationMatched = locationTerms.filter(x => containsSignal(text, x));
  if (locationTerms.length) {
    if (location.require && !locationMatched.length) {
      return {ok:false, score:0, trades:[], matched:[], locationMatched:[]};
    }
    if (locationMatched.length) bestScore += Math.min(12, locationMatched.length * 4);
  }

  if (/\b(llc|inc|licensed|insured|contractor|services|residential|commercial|estimate|builder|company|agency|studio|official)\b/i.test(text)) bestScore += 8;
  if (profile.bio && profile.bio.length > 20) bestScore += 5;

  return {
    ok: matchedTrades.length > 0,
    score: Math.min(100, bestScore),
    trades: [...new Set(matchedTrades)],
    matched: [...new Set(matched)],
    locationMatched: [...new Set(locationMatched)]
  };
}

function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, " and ")
    .replace(/[@#|•·.,:;_+\-()[\]{}\/\\]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenizeSignal(value) {
  return normalizeText(value).split(" ").filter(Boolean);
}

function expandVariant(value) {
  const out = new Set();
  const v = normalizeText(value);
  if (!v) return [];
  out.add(v);
  out.add(v.replace(/\s+/g, ""));
  const words = v.split(" ").filter(Boolean);
  for (const w of words) {
    out.add(w);
    if (w.endsWith("s") && w.length > 4) out.add(w.slice(0, -1));
    else if (w.length > 3) out.add(w + "s");
    if (w.endsWith("ian")) out.add(w + "s");
  }
  if (v.includes("contractor")) out.add(v.replace("contractor", "contractors"));
  if (v.includes("electrician")) {
    out.add(v.replace("electrician", "electricians"));
    out.add(v.replace("electrician", "electrical"));
    out.add("electric");
  }
  return [...out];
}

function containsSignal(text, signal) {
  const t = normalizeText(text);
  const s = normalizeText(signal);
  if (!s) return false;
  if (s.length <= 3) return new RegExp(`(^|\\s)${escapeRegExp(s)}(\\s|$)`, "i").test(t);
  if (new RegExp(`(^|\\s)${escapeRegExp(s)}(s|es|ing)?(\\s|$)`, "i").test(t)) return true;
  return t.replace(/\s+/g, "").includes(s.replace(/\s+/g, ""));
}

function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/* ------------------------ HELPERS ------------------------ */

async function openWorker(url) {
  if (S.tabId) {
    try {
      await chrome.tabs.update(S.tabId, {url, active:true});
      return await chrome.tabs.get(S.tabId);
    } catch(e) {
      S.tabId = null;
    }
  }
  const tab = await chrome.tabs.create({url, active:true});
  S.tabId = tab.id;
  return tab;
}

function waitLoad(tabId, timeout) {
  return new Promise(res => {
    let done = false;
    const finish = () => {
      if (!done) {
        done = true;
        chrome.tabs.onUpdated.removeListener(f);
        res();
      }
    };
    const f = (id, info) => {
      if (id === tabId && info.status === "complete") finish();
    };
    chrome.tabs.onUpdated.addListener(f);
    setTimeout(finish, timeout);
    chrome.tabs.get(tabId, tab => {
      if (tab && tab.status === "complete") finish();
    });
  });
}

async function pausePoint() {
  while (S.paused && !S.stop) await sleep(500);
}

function progress(phase, detail, percent) {
  send({
    type:"PROGRESS", phase, detail, percent,
    sourcesDone:S.sourcesDone, collected:S.collected,
    scanned:S.scanned, matched:S.matched
  });
}

function log(text) {
  send({type:"LOG", text:`${new Date().toLocaleTimeString()} — ${text}`});
}

function send(m) {
  chrome.runtime.sendMessage(m).catch(() => {});
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function userFromUrl(u) {
  try {
    if (!/^https?:/i.test(u)) u = "https://" + u;
    return new URL(u).pathname.replace(/^\/|\/$/g,"").split("/")[0];
  } catch(e) {
    return "";
  }
}
